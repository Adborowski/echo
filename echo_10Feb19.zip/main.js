console.log("[main.js]");

var xOffset = $("#boxActiveText").offset().left;
// var yOffset = $("#boxActiveText").offset().top;
var yOffset = $(window).height()-250;

  $("#mainInput").on("keydown", function(){

    $("#boxSavedTexts").prepend("<div class='boxSavedText'></div>");
    // find first child and offset it
    var newText = $("#boxSavedTexts").find(".boxSavedText:first");
    
    // populate with input content
    var inputValue = $(this).val();
    console.log(inputValue);

    console.log("NEWTEXT:");
    console.log(newText);

    // xOffset = xOffset + 10;
    yOffset = yOffset-3;

    // console.log(xOffset);
    console.log(yOffset);

    var currentX = newText.offset().left;
    var currentY = newText.offset().top;

    newText.offset({top: yOffset})
    newText.html(inputValue);

    var windowHeight = $(window).height();
   
  })
